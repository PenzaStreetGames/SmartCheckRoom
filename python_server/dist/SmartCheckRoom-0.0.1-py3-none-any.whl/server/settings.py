import os

"""Настройки подключения к MQTT-серверу"""

MQTT_HOST = "51.250.105.61"
# MQTT_HOST = "localhost"
MQTT_PORT = 1884

